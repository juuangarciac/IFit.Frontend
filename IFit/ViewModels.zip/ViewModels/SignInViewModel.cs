using CommunityToolkit.Mvvm.ComponentModel;
using IFit.Helper;
using IFit.Models.Dtos.Auth;
using IFit.Services;
using System.Diagnostics;
using System.Windows.Input;

namespace IFit.ViewModels
{
    /// <summary>
    /// ViewModel para la p�gina de inicio de sesi�n.
    /// Maneja autenticaci�n, validaci�n y navegaci�n post-login.
    /// </summary>
    public class SignInViewModel : ObservableObject
    {
        #region Fields

        private readonly AuthenticationService _authenticationService;
        private readonly AppUserService _appUserService;
        private readonly DatabaseService _databaseService;

        private string _email = string.Empty;
        private string _password = string.Empty;
        private bool _isLoading;
        private string _errorMessage = string.Empty;
        private bool _hasError;

        #endregion

        #region Properties

        /// <summary>
        /// Email del usuario (con binding bidireccional)
        /// </summary>
        public string Email
        {
            get => _email;
            set
            {
                if (SetProperty(ref _email, value))
                {
                    // Limpiar error al modificar
                    HasError = false;
                    ErrorMessage = string.Empty;

                    // Notificar que CanExecute del comando puede haber cambiado
                    OnPropertyChanged(nameof(CanLogin));
                }
            }
        }

        /// <summary>
        /// Contrase�a del usuario (con binding bidireccional)
        /// </summary>
        public string Password
        {
            get => _password;
            set
            {
                if (SetProperty(ref _password, value))
                {
                    // Limpiar error al modificar
                    HasError = false;
                    ErrorMessage = string.Empty;

                    // Notificar que CanExecute del comando puede haber cambiado
                    OnPropertyChanged(nameof(CanLogin));
                }
            }
        }

        /// <summary>
        /// Indica si se est� procesando el login
        /// </summary>
        public bool IsLoading
        {
            get => _isLoading;
            set
            {
                if (SetProperty(ref _isLoading, value))
                {
                    OnPropertyChanged(nameof(CanLogin));
                    OnPropertyChanged(nameof(StatusMessage));
                }
            }
        }

        /// <summary>
        /// Mensaje de error para mostrar al usuario
        /// </summary>
        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        /// <summary>
        /// Indica si hay un error activo
        /// </summary>
        public bool HasError
        {
            get => _hasError;
            set => SetProperty(ref _hasError, value);
        }

        #endregion

        #region Computed Properties

        /// <summary>
        /// Determina si se puede ejecutar el login
        /// </summary>
        public bool CanLogin => !IsLoading
                              && !string.IsNullOrWhiteSpace(Email)
                              && !string.IsNullOrWhiteSpace(Password);

        /// <summary>
        /// Mensaje de estado para la UI
        /// </summary>
        public string StatusMessage => IsLoading ? "Iniciando sesi�n..." : string.Empty;

        /// <summary>
        /// Texto del bot�n de login
        /// </summary>
        public string LoginButtonText => IsLoading ? "Iniciando..." : "Iniciar Sesi�n";

        #endregion

        #region Commands

        public ICommand LoginCommand { get; }

        #endregion

        #region Constructor

        public SignInViewModel(
            AuthenticationService authenticationService,
            AppUserService appUserService,
            DatabaseService databaseService)
        {
            // Inyecci�n de dependencias expl�cita
            _authenticationService = authenticationService ?? throw new ArgumentNullException(nameof(authenticationService));
            _appUserService = appUserService ?? throw new ArgumentNullException(nameof(appUserService));
            _databaseService = databaseService ?? throw new ArgumentNullException(nameof(databaseService));

            // Inicializar comandos
            LoginCommand = new Command(
                execute: async () => await SignInAsync(),
                canExecute: () => CanLogin
            );
        }

        /// <summary>
        /// Constructor sin par�metros para compatibilidad con XAML
        /// Obtiene servicios del service locator
        /// </summary>
        public SignInViewModel() : this(
            App.GetService<AuthenticationService>() ?? throw new InvalidOperationException("AuthenticationService no registrado"),
            App.GetService<AppUserService>() ?? throw new InvalidOperationException("AppUserService no registrado"),
            App.GetService<DatabaseService>() ?? throw new InvalidOperationException("DatabaseService no registrado"))
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Proceso principal de inicio de sesi�n
        /// </summary>
        public async Task SignInAsync()
        {
            try
            {
                IsLoading = true;
                HasError = false;
                ErrorMessage = string.Empty;

                Debug.WriteLine("Iniciando proceso de login");

                // 1. Validar inputs
                if (!ValidateInputs())
                {
                    return;
                }

                // 2. Intentar login
                var appUser = await TryLoginAsync();
                if (appUser == null)
                {
                    return;
                }

                Debug.WriteLine($"Login exitoso para usuario: {appUser.Email}");

                // 3. Guardar datos de sesi�n
                await SaveLoginData(appUser);

                // 4. Verificar si necesita completar el proceso de registro
                if (!appUser.RegistrationComplete)
                {
                    Debug.WriteLine("Usuario no ha completado registro inicial");

                    // 4a. Verificar email primero
                    if (!await HandleVerificationAsync(appUser))
                    {
                        return;
                    }

                    // 4b. Luego seleccionar coach y nivel de experiencia
                    if (!await HandleUserCoachAndExperienceLevel(appUser))
                    {
                        return;
                    }
                }

                // 5. Navegar a la pantalla principal
                Debug.WriteLine("Navegando a HomeView");
                await Shell.Current.GoToAsync("///HomeView");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error inesperado en SignInAsync: {ex.Message}");
                Debug.WriteLine($"StackTrace: {ex.StackTrace}");

                HasError = true;
                ErrorMessage = "Ocurri� un error inesperado. Por favor, intenta de nuevo.";

                await ErrorHandler.HandleErrorAsync(
                    "Error Inesperado",
                    "No se pudo completar el inicio de sesi�n. Por favor, intenta nuevamente."
                );
            }
            finally
            {
                IsLoading = false;
            }
        }

        /// <summary>
        /// Valida que los campos de email y contrase�a no est�n vac�os
        /// </summary>
        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(Email))
            {
                HasError = true;
                ErrorMessage = "Por favor, ingresa tu correo electr�nico.";
                Debug.WriteLine("Validaci�n fallida: Email vac�o");
                return false;
            }

            if (string.IsNullOrWhiteSpace(Password))
            {
                HasError = true;
                ErrorMessage = "Por favor, ingresa tu contrase�a.";
                Debug.WriteLine("Validaci�n fallida: Password vac�o");
                return false;
            }

            // Validaci�n adicional: formato de email
            if (!IsValidEmail(Email))
            {
                HasError = true;
                ErrorMessage = "Por favor, ingresa un correo electr�nico v�lido.";
                Debug.WriteLine($"Validaci�n fallida: Email inv�lido: {Email}");
                return false;
            }

            Debug.WriteLine("Validaci�n exitosa");
            return true;
        }

        /// <summary>
        /// Valida el formato del email
        /// </summary>
        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Intenta hacer login con las credenciales proporcionadas
        /// </summary>
        /// <returns>Datos del usuario si el login es exitoso, null en caso contrario</returns>
        private async Task<AppUserResponseDto?> TryLoginAsync()
        {
            try
            {
                Debug.WriteLine($"Intentando login para: {Email}");

                var response = await _authenticationService.LoginAsync(Email, Password);

                if (response == null)
                {
                    HasError = true;
                    ErrorMessage = "Credenciales incorrectas. Por favor, verifica tu email y contrase�a.";

                    Debug.WriteLine("Login fallido: Respuesta nula del servidor");

                    await ErrorHandler.HandleErrorAsync(
                        "Error de Inicio de Sesi�n",
                        "No se pudo iniciar sesi�n. Por favor, verifica tus credenciales."
                    );

                    return null;
                }

                if (response.AppUser == null)
                {
                    HasError = true;
                    ErrorMessage = "Error al obtener datos del usuario.";

                    Debug.WriteLine("Login fallido: AppUser es null");

                    await ErrorHandler.HandleErrorAsync(
                        "Error",
                        "No se pudieron obtener los datos del usuario."
                    );

                    return null;
                }

                Debug.WriteLine($"Login exitoso. UserId: {response.AppUser.Id}");
                return response.AppUser;
            }
            catch (Exception ex)
            {
                HasError = true;
                ErrorMessage = "Error de conexi�n. Por favor, verifica tu conexi�n a internet.";

                Debug.WriteLine($"Excepci�n en TryLoginAsync: {ex.Message}");

                await ErrorHandler.HandleErrorAsync(
                    "Error de Conexi�n",
                    "No se pudo conectar con el servidor. Por favor, verifica tu conexi�n a internet."
                );

                return null;
            }
        }

        /// <summary>
        /// Guarda los datos del usuario en Preferences y base de datos local
        /// </summary>
        private async Task SaveLoginData(AppUserResponseDto dto)
        {
            try
            {
                Debug.WriteLine($"Guardando datos de login para usuario: {dto.Email}");

                // Guardar en Preferences para acceso r�pido
                Preferences.Set("UserId", dto.Id);
                Preferences.Set("UserEmail", dto.Email);
                Preferences.Set("Name", dto.Name);
                Preferences.Set("IsVerified", dto.Verified);

                if (!string.IsNullOrEmpty(dto.CoachModelTypeName))
                {
                    Preferences.Set("CoachModelTypeName", dto.CoachModelTypeName);
                }

                Debug.WriteLine("Datos guardados en Preferences");

                // Guardar en base de datos local
                await InsertUserToDatabase(dto);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error guardando datos de login: {ex.Message}");
                // No bloqueamos el flujo si falla el guardado local
                // El usuario ya est� autenticado en el servidor
            }
        }

        /// <summary>
        /// Verifica si el usuario ha confirmado su email
        /// </summary>
        private async Task<bool> HandleVerificationAsync(AppUserResponseDto appUser)
        {
            try
            {
                if (!appUser.Verified)
                {
                    Debug.WriteLine("Usuario no verificado, navegando a VerificationView");

                    // Opcionalmente enviar email de verificaci�n
                    // await _authenticationService.SendVerificationEmail(Email);

                    await Shell.Current.GoToAsync("///VerificationView");
                    return false;
                }

                Debug.WriteLine("Usuario verificado correctamente");
                Preferences.Set("IsVerified", true);
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error en HandleVerificationAsync: {ex.Message}");

                await ErrorHandler.HandleErrorAsync(
                    "Error",
                    "No se pudo verificar el estado del usuario. Por favor, intenta nuevamente."
                );

                return false;
            }
        }

        /// <summary>
        /// Verifica si el usuario ha seleccionado coach y nivel de experiencia
        /// </summary>
        private async Task<bool> HandleUserCoachAndExperienceLevel(AppUserResponseDto appUser)
        {
            try
            {
                var needsCoachSelection = string.IsNullOrEmpty(appUser.CoachModelTypeName);
                var needsExperienceLevel = string.IsNullOrEmpty(appUser.ExperienceLevelName);

                if (needsCoachSelection || needsExperienceLevel)
                {
                    Debug.WriteLine($"Usuario necesita completar setup - Coach: {needsCoachSelection}, Experience: {needsExperienceLevel}");

                    await Shell.Current.GoToAsync("///GetStartedView");
                    return false;
                }

                Debug.WriteLine("Usuario tiene coach y nivel de experiencia configurados");
                Preferences.Set("CoachModelTypeName", appUser.CoachModelTypeName);

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error en HandleUserCoachAndExperienceLevel: {ex.Message}");

                await ErrorHandler.HandleErrorAsync(
                    "Error",
                    "No se pudo verificar la configuraci�n del usuario."
                );

                return false;
            }
        }

        /// <summary>
        /// Guarda el usuario en la base de datos local SQLite
        /// </summary>
        private async Task InsertUserToDatabase(AppUserResponseDto appUser)
        {
            try
            {
                Debug.WriteLine($"Insertando usuario en BD local: {appUser.Email}");

                var entity = appUser.toEntity();
                await _databaseService.InsertAppUserAsync(entity);

                Debug.WriteLine("Usuario guardado en BD local exitosamente");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error guardando usuario en BD local: {ex.Message}");
                Debug.WriteLine($"StackTrace: {ex.StackTrace}");

                // No lanzamos excepci�n porque el login ya fue exitoso
                // La BD local es solo para cach�
                // El usuario puede continuar usando la app
            }
        }

        #endregion

        #region Public Methods (para testing o uso externo)

        /// <summary>
        /// Limpia los campos del formulario
        /// </summary>
        public void ClearForm()
        {
            Email = string.Empty;
            Password = string.Empty;
            HasError = false;
            ErrorMessage = string.Empty;

            Debug.WriteLine("Formulario limpiado");
        }

        /// <summary>
        /// Limpia solo los errores
        /// </summary>
        public void ClearErrors()
        {
            HasError = false;
            ErrorMessage = string.Empty;
        }

        #endregion
    }
}